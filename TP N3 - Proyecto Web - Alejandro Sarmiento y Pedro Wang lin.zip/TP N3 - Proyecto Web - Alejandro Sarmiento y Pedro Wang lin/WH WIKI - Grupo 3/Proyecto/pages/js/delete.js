document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("userMenuToggle");
  const dropdown = document.getElementById("userDropdown");
  const logoutBtn = document.getElementById("logoutBtn");
  const welcomeUser = document.getElementById("welcomeUser");

  // Mostrar nombre del usuario logueado
  const currentUser = localStorage.getItem("currentUser");
  if (currentUser) {
    welcomeUser.textContent = `👋 Hola, ${currentUser}`;
  } else {
    welcomeUser.textContent = "Usuario invitado";
  }

  // Alternar menú desplegable
  toggle.addEventListener("click", (e) => {
    e.stopPropagation(); // evita cierre inmediato
    dropdown.style.display =
      dropdown.style.display === "flex" ? "none" : "flex";
  });

  // Cerrar menú al hacer clic fuera
  document.addEventListener("click", () => {
    dropdown.style.display = "none";
  });

  // Cerrar sesión
  logoutBtn.addEventListener("click", () => {
    const confirmLogout = confirm("¿Seguro que deseas cerrar sesión?");
    if (confirmLogout) {
      localStorage.removeItem("currentUser");
      alert("👋 Sesión cerrada correctamente.");
      window.location.href = "login.html";
    }
  });
});
