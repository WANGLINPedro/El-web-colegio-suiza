document.addEventListener("DOMContentLoaded", () => {
  const loginBtn = document.querySelector(".submit");
  const card = document.querySelector(".card");


  const rippleContainer = document.createElement("div");
  rippleContainer.id = "ripple-container";
  document.body.appendChild(rippleContainer);

  loginBtn.addEventListener("click", login);

  function login(event) {
    event.preventDefault();

    const inputs = document.querySelectorAll("input");
    const user = inputs[0].value.trim();
    const password = inputs[1].value.trim();

    if (!user || !password) {
      alert("⚠️ Por favor, completa todos los campos.");
      return;
    }


    const users = JSON.parse(localStorage.getItem("users")) || [];

    const found = users.find((u) => u.user === user && u.password === password);

    if (found) {
      localStorage.setItem("currentUser", user);
      alert("✅ Has iniciado sesión correctamente.");
      window.location.href = "inicio.html";
    } else {
      alert("❌ Usuario o contraseña incorrectos.");
    }
  }

  
  document.addEventListener("click", (e) => {
    if (!card.contains(e.target)) {
      const ripple = document.createElement("span");
      ripple.classList.add("ripple");
      ripple.style.left = `${e.clientX - 50}px`;
      ripple.style.top = `${e.clientY - 50}px`;
      rippleContainer.appendChild(ripple);

      setTimeout(() => ripple.remove(), 1200);
    }
  });
});
