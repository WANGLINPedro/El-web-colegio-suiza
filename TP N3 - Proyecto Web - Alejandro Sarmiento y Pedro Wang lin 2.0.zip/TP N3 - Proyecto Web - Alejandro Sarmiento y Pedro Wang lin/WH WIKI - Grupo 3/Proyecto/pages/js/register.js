document.addEventListener("DOMContentLoaded", () => {
  const registerBtn = document.querySelector(".submit");
  const rippleContainer = document.getElementById("ripple-container");
  const card = document.querySelector(".card");

  registerBtn.addEventListener("click", register);

  function register(event) {
    event.preventDefault();


    const inputs = document.querySelectorAll("input");
    const user = inputs[0].value.trim();
    const password = inputs[1].value.trim();
    const confirmPassword = inputs[2].value.trim();


    if (!user || !password || !confirmPassword) {
      alert("⚠️ Por favor, completa todos los campos.");
      return;
    }


    if (password !== confirmPassword) {
      alert("⚠️ Las contraseñas no coinciden.");
      return;
    }

    let users = JSON.parse(localStorage.getItem("users")) || [];


    const exists = users.find((u) => u.user === user);
    if (exists) {
      alert("⚠️ El usuario ya existe, elige otro nombre.");
      return;
    }


    users.push({ user, password });
    localStorage.setItem("users", JSON.stringify(users));

    alert("✅ Usuario registrado correctamente.");
    window.location.href = "login.html";
  }


  document.addEventListener("click", (e) => {
    if (!card.contains(e.target)) {
      const ripple = document.createElement("span");
      ripple.classList.add("ripple");
      ripple.style.left = `${e.clientX - 50}px`;
      ripple.style.top = `${e.clientY - 50}px`;
      rippleContainer.appendChild(ripple);

      setTimeout(() => ripple.remove(), 1200);
    }
  });
});
