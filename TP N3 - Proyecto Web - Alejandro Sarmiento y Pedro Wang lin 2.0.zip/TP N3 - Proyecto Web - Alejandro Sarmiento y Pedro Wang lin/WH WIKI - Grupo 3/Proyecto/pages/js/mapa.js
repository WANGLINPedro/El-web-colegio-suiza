// 🗺️ --- VARIABLES Y ELEMENTOS ---
const modal = document.getElementById("mapModal");
const trigger = document.querySelector(".map-trigger");
const closeBtn = document.querySelector(".close");
const zoomInBtn = document.getElementById("zoomIn");
const zoomOutBtn = document.getElementById("zoomOut");
const mapImage = document.getElementById("mapImage");
const mapContainer = document.querySelector(".map-container");

let scale = 1;
let isDragging = false;
let startX = 0, startY = 0;
let translateX = 0, translateY = 0;

// --- Evitar drag nativo de la imagen ---
mapImage.setAttribute("draggable", "false");
mapImage.style.userSelect = "none";
mapImage.style.webkitUserSelect = "none";
mapImage.style.msUserSelect = "none";
mapImage.style.pointerEvents = "auto";
mapImage.addEventListener("dragstart", (e) => e.preventDefault());

// --- Abrir y resetear ---
trigger.addEventListener("click", () => {
  modal.style.display = "flex";
  resetMapPosition();
});

// --- Cerrar modal ---
closeBtn.addEventListener("click", () => {
  modal.style.display = "none";
});

// --- Zoom In / Out ---
zoomInBtn.addEventListener("click", () => {
  scale = Math.min(scale + 0.2, 3);
  clampPosition();
  updateTransform();
});

zoomOutBtn.addEventListener("click", () => {
  scale = Math.max(0.6, scale - 0.2);
  clampPosition();
  updateTransform();
});

// --- Arrastrar mapa (solo con click izquierdo) ---
mapContainer.addEventListener("mousedown", (e) => {
  if (e.button !== 0) return; // solo botón izquierdo
  if (e.target.closest(".map-toolbar")) return; // evitar que botones activen arrastre

  isDragging = true;
  startX = e.clientX - translateX;
  startY = e.clientY - translateY;
  mapContainer.style.cursor = "grabbing";

  // evitar selección de texto mientras arrastramos
  document.body.style.userSelect = "none";
});

window.addEventListener("mouseup", () => {
  isDragging = false;
  mapContainer.style.cursor = "grab";
  document.body.style.userSelect = "";
});

window.addEventListener("mousemove", (e) => {
  if (!isDragging) return;
  translateX = e.clientX - startX;
  translateY = e.clientY - startY;
  clampPosition();
  updateTransform();
});

// --- FUNCIONES AUXILIARES ---
// Mantiene el mapa dentro del contenedor
function clampPosition() {
  const rect = mapContainer.getBoundingClientRect();
  const imgWidth = mapImage.offsetWidth * scale;
  const imgHeight = mapImage.offsetHeight * scale;

  const halfDiffX = Math.max(0, (imgWidth - rect.width) / 2);
  const halfDiffY = Math.max(0, (imgHeight - rect.height) / 2);

  translateX = Math.min(halfDiffX, Math.max(-halfDiffX, translateX));
  translateY = Math.min(halfDiffY, Math.max(-halfDiffY, translateY));
}

// Reset al abrir
function resetMapPosition() {
  scale = 1;
  translateX = 0;
  translateY = 0;
  updateTransform();
}

// Aplicar transformaciones (zoom + posición)
function updateTransform() {
  mapImage.style.transform = `translate(${translateX}px, ${translateY}px) scale(${scale})`;
}
