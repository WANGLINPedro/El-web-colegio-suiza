const reveals = document.querySelectorAll('.reveal');

function revealOnScroll() {
  const triggerBottom = window.innerHeight * 0.85; // activa un poco antes de que aparezca completamente

  reveals.forEach((el, i) => {
    const top = el.getBoundingClientRect().top;

    if (top < triggerBottom) {
      // Aparece con un pequeño retraso escalonado
      setTimeout(() => {
        el.classList.add('active');
      }, i * 150); // 150 ms entre cada bloque
    }
  });
}

window.addEventListener('scroll', revealOnScroll);
revealOnScroll(); // Ejecutar una vez al cargar
