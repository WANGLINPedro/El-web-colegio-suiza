
const hamburger = document.getElementById("hamburgerMenu");
const nav = document.querySelector("nav");

hamburger.addEventListener("click", () => {
    nav.classList.toggle("active");
});

