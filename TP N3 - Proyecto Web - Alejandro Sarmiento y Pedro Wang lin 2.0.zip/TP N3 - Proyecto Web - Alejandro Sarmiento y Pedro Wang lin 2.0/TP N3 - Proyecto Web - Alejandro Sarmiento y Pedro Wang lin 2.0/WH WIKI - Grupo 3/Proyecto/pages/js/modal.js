

const modal = document.getElementById("mailModal");
const closeBtn = document.querySelector(".close");
const emailInput = document.getElementById("emailInput");
const sendButton = document.getElementById("sendEmail");

// Abrir modal cuando tocan la imagen
document.querySelector(".open-mail-modal").onclick = () => {
    modal.style.display = "flex";
    emailInput.focus();
};

// Botón cerrar
closeBtn.onclick = () => {
    modal.style.display = "none";
};

// Cerrar si hacen clic afuera
window.onclick = e => {
    if (e.target === modal) modal.style.display = "none";
};

// Acción del botón enviar
sendButton.onclick = () => {
    const email = emailInput.value.trim();

    if (email === "") {
        alert("Por favor, escribe un email válido.");
        return;
    }

    alert("Email enviado: " + email);
    modal.style.display = "none";
    emailInput.value = "";
};


