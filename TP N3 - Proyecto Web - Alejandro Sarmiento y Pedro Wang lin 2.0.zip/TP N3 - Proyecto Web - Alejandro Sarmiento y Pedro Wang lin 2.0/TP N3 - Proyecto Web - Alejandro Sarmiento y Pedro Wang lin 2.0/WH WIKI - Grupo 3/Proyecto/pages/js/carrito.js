document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll(".texto button");
    const cartCount = document.getElementById("cartCount");
    const cartModal = document.getElementById("cartModal");
    const cartIcon = document.getElementById("cartIcon");
    const cartItems = document.getElementById("cartItems");
    const cartTotal = document.getElementById("cartTotal");
    const closeCart = document.getElementById("closeCart");
    const clearCart = document.getElementById("clearCart");

    // 🛒 Cargar carrito desde localStorage o inicializar vacío
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    updateCart();

    // ➕ Agregar producto al carrito
    buttons.forEach(btn => {
        btn.addEventListener("click", (e) => {
            const productDiv = e.target.closest("div.texto");
            const name = productDiv.querySelector("p").textContent.trim();
            const priceText = productDiv.querySelector("strong").textContent.replace("$","").replace("€","").replace("USD","").trim();
            const price = parseFloat(priceText);

            const product = { name, price };
            cart.push(product);
            saveCart();
            updateCart();
            alert(`${name} agregado al carrito 🛒`);
        });
    });

    // 👀 Mostrar modal del carrito
    cartIcon.addEventListener("click", () => {
        renderCart();
        cartModal.style.display = "flex";
    });

    // ❌ Cerrar modal
    closeCart.addEventListener("click", () => {
        cartModal.style.display = "none";
    });

    // 🧹 Vaciar carrito
    clearCart.addEventListener("click", () => {
        if(confirm("¿Seguro que deseas vaciar el carrito?")) {
            cart = [];
            saveCart();
            updateCart();
            renderCart();
        }
    });

    // 💾 Guardar carrito
    function saveCart() {
        localStorage.setItem("cart", JSON.stringify(cart));
    }

    // 🔄 Actualizar contador
    function updateCart() {
        cartCount.textContent = cart.length;
        localStorage.setItem("cart", JSON.stringify(cart));
    }

    // 🧾 Mostrar productos en el modal
    function renderCart() {
        cartItems.innerHTML = "";
        let total = 0;

        if(cart.length === 0) {
            cartItems.innerHTML = "<li>Tu carrito está vacío 🕳️</li>";
        } else {
            cart.forEach(item => {
                const li = document.createElement("li");
                li.textContent = `${item.name} - $${item.price.toFixed(2)}`;
                cartItems.appendChild(li);
                total += item.price;
            });
        }

        cartTotal.textContent = total.toFixed(2);
    }
});
