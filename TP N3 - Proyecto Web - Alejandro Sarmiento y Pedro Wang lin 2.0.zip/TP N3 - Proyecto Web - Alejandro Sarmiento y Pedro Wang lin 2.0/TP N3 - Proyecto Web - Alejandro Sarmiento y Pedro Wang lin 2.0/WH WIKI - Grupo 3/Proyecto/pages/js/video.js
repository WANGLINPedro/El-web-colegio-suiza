document.addEventListener("DOMContentLoaded", () => {

    const modal = document.getElementById("modal-video");
    const videoPlayer = document.getElementById("video-player");
    const closeBtn = document.querySelector(".video-close");

    // Abrir modal al hacer clic en cualquier imagen trigger
    document.querySelectorAll(".video-trigger").forEach(trigger => {
        trigger.addEventListener("click", () => {
            const videoSrc = trigger.getAttribute("data-video");

            modal.style.display = "flex";
            videoPlayer.src = videoSrc;
            videoPlayer.play();
        });
    });

    // Botón para cerrar
    closeBtn.addEventListener("click", () => {
        cerrarModal();
    });

    // Cerrar clickeando fuera
    window.addEventListener("click", (e) => {
        if (e.target === modal) cerrarModal();
    });

    // Función para cerrar el modal
    function cerrarModal() {
        modal.style.display = "none";
        videoPlayer.pause();
        videoPlayer.currentTime = 0;
        videoPlayer.src = ""; // limpia el video
    }

});
