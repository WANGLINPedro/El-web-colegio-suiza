
// abrir y cerrar modal
const modal = document.getElementById("contactModal");
const openBtn = document.getElementById("openModal");
const closeBtn = document.getElementById("closeModal");

openBtn.addEventListener("click", () => {
    modal.style.display = "flex";

    // Si el email ya existe, lo autocompleta
    const savedEmail = localStorage.getItem("userEmail");
    if (savedEmail) {
        document.getElementById("emailInput").value = savedEmail;
    }
});

closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
});

// enviar formulario
document.getElementById("contactForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const email = document.getElementById("emailInput").value;
    const mensaje = document.getElementById("msgInput").value;

    // Guardar email en localStorage
    localStorage.setItem("userEmail", email);

    alert("Mensaje enviado correctamente.");

    modal.style.display = "none";
});



    const burgerBtn = document.getElementById("burgerBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    burgerBtn.addEventListener("click", () => {
        mobileMenu.classList.toggle("open");
    });